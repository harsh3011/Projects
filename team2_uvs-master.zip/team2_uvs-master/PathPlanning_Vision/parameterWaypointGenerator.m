% Base deiniions for the Waypoint Generator

% Maximum distance before waypoint switch in meters
maxwaydist = 0.5;

% Maximum distance before terminating at goal in meters
maxgoaldist = 0.3;



